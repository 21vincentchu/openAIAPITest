#!/usr/bin/env python3
import argparse, os, re, unicodedata
from pathlib import Path
import numpy as np
from ollama import Client

# ---- CONFIG (tweak if you like) ----
OLLAMA_URL   = "http://127.0.0.1:11434"
EMBED_MODEL  = "nomic-embed-text"
GEN_MODEL    = "llama3.2:3b"
CHUNK_SIZE   = 1000   # characters
CHUNK_OVERLAP= 200
TOP_K        = 4
NUM_CTX      = 1024
NUM_PREDICT  = 256

client = Client(host=OLLAMA_URL)

def clean_text(s: str) -> str:
    s = unicodedata.normalize("NFKC", s)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = re.sub(r'-\s*\n', '', s)             # fix hyphenated line breaks
    s = re.sub(r'[ \t]+', ' ', s)            # collapse spaces/tabs
    s = re.sub(r'\n{3,}', '\n\n', s)         # tidy blank lines
    return s.strip()

def chunk_text(s, size=CHUNK_SIZE, overlap=CHUNK_OVERLAP):
    # paragraph-aware chunking; slices very long paragraphs with overlap
    paras = [p.strip() for p in s.split("\n\n") if p.strip()]
    chunks, cur = [], ""
    for p in paras:
        if len(cur) + len(p) + 2 <= size:
            cur = (cur + "\n\n" + p) if cur else p
        else:
            if cur:
                chunks.append(cur)
            # slice long paragraph
            i, step = 0, max(1, size - overlap)
            while i < len(p):
                chunks.append(p[i:i+size])
                i += step
            cur = ""
    if cur:
        chunks.append(cur)
    return chunks

def embed_texts(texts):
    # Compatible with ollama client versions that do NOT accept list prompts
    if isinstance(texts, str):
        resp = client.embeddings(model=EMBED_MODEL, prompt=texts)
        return np.array(resp["embedding"], dtype=np.float32)
    out = []
    for t in texts:
        resp = client.embeddings(model=EMBED_MODEL, prompt=t)
        out.append(resp["embedding"])
    return np.array(out, dtype=np.float32)

def read_txt_files(path: Path):
    if path.is_file() and path.suffix.lower() == ".txt":
        return [path]
    if path.is_dir():
        return sorted([p for p in path.rglob("*.txt") if p.is_file()])
    raise SystemExit(f"Path not a .txt file or folder: {path}")

def index_path(path_str, out_path):
    base = Path(path_str).expanduser().resolve()
    files = read_txt_files(base)
    if not files:
        raise SystemExit("No .txt files found.")
    texts, meta = [], []
    for fp in files:
        try:
            t = fp.read_text(errors="ignore")
        except Exception:
            t = ""
        t = clean_text(t)
        if not t:
            continue
        for i, chunk in enumerate(chunk_text(t)):
            texts.append(chunk)
            meta.append({"source": str(fp), "chunk": i})
    if not texts:
        raise SystemExit("No text content found to index.")
    print(f"Embedding {len(texts)} chunks from {len(files)} file(s)…")
    embs = embed_texts(texts).astype(np.float32)
    # normalize rows for cosine via dot product
    norms = np.linalg.norm(embs, axis=1, keepdims=True) + 1e-9
    embs = embs / norms
    out = Path(out_path).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out, embeddings=embs, texts=np.array(texts, dtype=object), meta=np.array(meta, dtype=object))
    print(f"Indexed → {out}")

def load_index(out_path):
    data = np.load(Path(out_path), allow_pickle=True)
    E = data["embeddings"].astype(np.float32)
    T = data["texts"].tolist()
    M = data["meta"].tolist()
    return E, T, M

def retrieve(query, E, T, M, k=TOP_K):
    q = embed_texts(query)
    q = q / (np.linalg.norm(q) + 1e-9)
    sims = E @ q
    idx = np.argsort(-sims)[:k]
    return [(T[i], M[i], float(sims[i])) for i in idx]

def answer_from_context(question, hits):
    context = ""
    sources = []
    for i, (text, meta, score) in enumerate(hits, 1):
        context += f"\n[{i}] {text[:1200]}\n"
        sources.append(f"[{i}] {meta['source']} (chunk {meta['chunk']})  score={score:.3f}")
    prompt = f\"\"\"You MUST answer using ONLY the context below. If the answer is not fully in the context, say "I don't know."
Keep answers concise and in English.

# Context
{context}

# Question
{question}

# Answer
\"\"\"
    stream = client.chat(
        model=GEN_MODEL,
        options={
            "num_ctx": NUM_CTX,
            "num_predict": NUM_PREDICT,
            "temperature": 0.2,
            "top_k": 50,
            "top_p": 0.9,
            "repeat_penalty": 1.2,
            "repeat_last_n": 256
        },
        messages=[{"role":"user","content": prompt}],
        stream=True
    )
    for chunk in stream:
        msg = chunk.get("message", {})
        if "content" in msg:
            print(msg["content"], end="", flush=True)
    print("\n\nSources:")
    for s in sources:
        print(" -", s)

def main():
    ap = argparse.ArgumentParser(description="Tiny CLI RAG over .txt using Ollama for embed+gen")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_idx = sub.add_parser("index", help="Index a file or folder of .txt")
    p_idx.add_argument("--path", required=True, help="File or folder to index")
    p_idx.add_argument("--out",  default="kb.npz", help="Index output path")

    p_ask = sub.add_parser("ask", help="Ask against an index")
    p_ask.add_argument("--index", default="kb.npz", help="Path to .npz index")
    p_ask.add_argument("--q", required=True, help="Question text")
    p_ask.add_argument("--debug", action="store_true", help="Print retrieved chunks")

    args = ap.parse_args()

    if args.cmd == "index":
        index_path(args.path, args.out)
    elif args.cmd == "ask":
        E, T, M = load_index(args.index)
        hits = retrieve(args.q, E, T, M, k=TOP_K)
        if args.debug:
            for i,(t,m,s) in enumerate(hits,1):
                print(f"\n---[HIT {i} | {s:.3f}] {m['source']} chunk {m['chunk']}---\n{t[:800]}\n")
        answer_from_context(args.q, hits)

if __name__ == "__main__":
    main()
