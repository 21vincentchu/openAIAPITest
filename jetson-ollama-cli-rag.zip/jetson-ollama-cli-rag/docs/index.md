---
title: Jetson Ollama CLI RAG
---

# Jetson Ollama CLI RAG (No GUI)

This site documents a tiny, **CLI-only** Retrieval-Augmented Generation pipeline we built on a **Jetson Orin Nano 8 GB**. It uses **Ollama** for both embeddings and generation and a lightweight `.npz` vector index. Perfect when you want a fast, local, private Q&A over a folder of `.txt` files — **no web UI**.

## What We Achieved
- ✅ Installed Ollama with CUDA on Jetson.
- ✅ Verified models run from the terminal.
- ✅ Implemented a simple RAG script (`rag_simple.py`) with cleaning + chunking.
- ✅ Answer from your docs only (if not present, it says “I don’t know”).

## Quickstart
```bash
# Pull models
ollama pull llama3.2:3b
ollama pull nomic-embed-text

# Index a file or folder of .txt
python3 rag_simple.py index --path ./my_docs --out kb.npz

# Ask a question
python3 rag_simple.py ask --index kb.npz --q "What is the recommended minimum distance ...?" --debug
```

**Tip:** Keep `NUM_CTX=1024`, `NUM_PREDICT=256` for smoother performance on Nano.  
For snappier responses, try `qwen2.5:3b` or `phi3.5:mini` as the generation model.

## Repo
See the code and usage in the repository root:
- `rag_simple.py` — the entire pipeline in ~150 lines
- `requirements.txt` — Python deps
- `README.md` — usage and notes

## Roadmap
- PDF/Docx ingestion (convert to text)
- Auto re-index when files change
- Thresholding + reranking for higher precision
- Optional FAISS/Chroma for bigger corpora
