# Jetson Ollama CLI RAG (No GUI)

A tiny, **CLI-only** Retrieval-Augmented Generation pipeline for **Jetson Orin Nano 8 GB**.  
Uses **Ollama** for both embeddings and generation, and a super-light `.npz` vector index.

## Why
- No web UI, no Docker UIs — **all terminal**.
- Runs well on Jetson Nano 8 GB with small models (e.g., `llama3.2:3b`).
- Ground answers strictly in your local `.txt` files.

## Features
- Paragraph-aware chunking + cleaning (fix hyphenated line breaks).
- Embeddings + cosine similarity search.
- Answers **only from your documents** (otherwise “I don’t know”).

## Requirements
- Jetson with CUDA + [Ollama](https://ollama.com)
- Python 3.8+
- `ollama` Python package, `numpy`

## Install
```bash
# 1) Install Ollama on the Jetson (CUDA-enabled)
curl -fsSL https://ollama.com/install.sh | sh

# 2) Pull models (generation + embeddings)
ollama pull llama3.2:3b
ollama pull nomic-embed-text

# 3) Python deps (inside your repo folder)
python3 -m pip install -r requirements.txt
```

## Usage
```bash
# Index a single file
python3 rag_simple.py index --path "/absolute/path/to/YourDoc.txt" --out kb.npz

# Or index a folder of .txt files
python3 rag_simple.py index --path ./docs_src --out kb.npz

# Ask a question (pure CLI, streams tokens)
python3 rag_simple.py ask --index kb.npz --q "Your question here" --debug
```

**Tip:** For faster replies, try a smaller gen model:
```bash
ollama pull qwen2.5:3b
# then edit GEN_MODEL = "qwen2.5:3b" at top of rag_simple.py
```

## Project Status
- ✅ Working end-to-end pipeline (file/folder → index → retrieve → answer).
- ✅ Tested with `llama3.2:3b` on Jetson Orin Nano 8 GB.
- 🔜 Planned: PDF/Docx ingestion, folder auto-watch, FAISS/Chroma backend.

## Troubleshooting
- If output looks garbled, re-index after cleaning is enabled (already in script).
- If `kb.npz` corrupts (e.g., interrupted write), delete and rebuild.
- If embeddings call errors on list inputs, keep this repo’s version (we embed chunks one-by-one).

## License
MIT
